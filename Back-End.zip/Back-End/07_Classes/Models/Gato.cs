using System;

namespace Heranca
{
    public class Gato
    {
        public string nome { get; set; }

        public int idade { get; set; }

        public string genero { get; set; }

    }
}
using System;

namespace Heranca
{
    public class Peixe
    {
       public decimal tamanho { get; set; }
    }
}
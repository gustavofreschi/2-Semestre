using System;

namespace Heranca
{
    public class Animal
    {
        public string cor { get; set; }

        public string especie { get; set; }

        public decimal peso { get; set; }

    }
}
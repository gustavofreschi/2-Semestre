using System;

namespace Heranca
{
    public class Peixe : Animal
    {
        public decimal tamanho { get; set; }
    }
}
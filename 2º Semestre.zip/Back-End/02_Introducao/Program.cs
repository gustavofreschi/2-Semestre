﻿//Somente declaramos a variável como inteira e não atribuimos valor
int num1;

//Declarando uma variável do tipo inteiro e atribuindo o valor 5
int num2 = 5;

//Declarando uma variável do tipo String (texto)
String nomeAluno;

//Variável do tipo lógico (verdadeiro ou falso)
bool resultado = true;

//Variável de tipo valot com casas decimais - para valores mais precisos
double coordenadas = 1.80;

//Variável do tipo decimal - mais usada para valor monetário
decimal valor = 1.80M;

